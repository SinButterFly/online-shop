<?php

require 'db.php';
$sql = 'SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id';
$stmt = $pdo->prepare($sql);
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_OBJ);
 ?>
<?php require 'header.php'; ?>
<div class="container">
  <div class="mt-5">
    <div class="header">
      <h2>Продукты</h2>
    </div>
    <div class="row">
      <?php foreach($products as $product): ?>
          
          <div class="card" style="width: 25%">
            <div class="img_wrap">
              <img src="<?= $product->photo; ?>" alt="<?= $product->photo; ?>"style="width: 12rem; margin:auto;">
            </div>
            <div class="card-body">
              <h5 class="card-title"><?= $product->name; ?></h5>
              <p class="card-text"><?= $product->desc_p; ?></p>
              <p class="card-text"><?= $product->price; ?></p>
              <p class="card-text"><?= $product->name_cat; ?></p>
              <a href="edit.php?id=<?= $product->id_prod ?>" class="btn btn-info">Редактировать</a>
              <a onclick="return confirm('Действительно хотите удалить?')" href="delete.php?id=<?= $product->id_prod ?>" class='btn btn-danger'>Удалить</a>
            </div>
          </div>
          
      <?php endforeach; ?>
      </div>
  </div>
</div>
<?php require 'footer.php'; ?>

//фильтрация по категории
