<?php
session_start();
require_once 'db.php';
require_once 'cart.php';

$cart = new Cart();
foreach($cart->cart as $id => $count) {
    $stmt = $pdo->query("SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id WHERE id_prod='$id'");
}

if (isset($_POST['arrange'])) {
    $name_customer = $_POST['name_customer'];
    $email_customer = $_POST['email_customer'];
    $tel_customer = $_POST['tel_customer'];
    $delivery = $_POST['delivery'];

    $customer = "INSERT INTO `customers` (name_customer, email_customer, tel_customer)
          VALUES('$name_customer', '$email_customer', '$tel_customer')";
    $stmt = $pdo->prepare($customer);
    $stmt -> execute([$name_customer => $name_customer, $email_customer => $email_customer, $tel_customer => $tel_customer]);


    $customer_id = $pdo->lastInsertId();

    $order = "INSERT INTO `orders` (delivery, customer_id)
          VALUES('$delivery', '$customer_id')";
    $stmt2 = $pdo->prepare($order);
    $stmt2 -> execute([$delivery => $delivery, $customer_id => $customer_id]);

    $cart = new Cart();
    $price = 0;
    $order_id = $pdo -> lastInsertId();

    foreach($cart->cart as $id => $count){
        $cart_p = "INSERT INTO `products_cart` (`product_id`,`count`,`orders_id`)
        VALUE ('$id','$count','$order_id')";
        $stmt3 = $pdo->prepare($cart_p);
        $stmt3 -> execute([$id => $id, $count => $count, $order_id => $order_id]);

    }
    require_once 'mail.php';
}




require_once 'header.php';
?>

<div class="container">
    <h2>Оформление заказа</h2>
    <div class="row">
        <div class="col-8 data-wrap">
            <div class="user-form">

                <form action="page_order.php" method="post">
                    <h4>Данные пользователя</h4>
                    <div class="form-group">

                        <input class="form-control" name="name_customer" type="text" placeholder="Имя">
                        <input class="form-control" name="email_customer" type="email" placeholder="Email">
                        <input class="form-control" name="tel_customer" type="text" placeholder="Телефон">

                    </div>
                    <h4>Доставка</h4>
                    <select name="delivery" id="delivery">
                        <option value="0">Способ доставки</option>
                        <option value="1">Курьер</option>
                        <option value="2">Самовывоз</option>
                    </select>

                    <input type="submit" value="Оформить заказ" name="arrange">

                </form>
            </div>
        </div>
        <!-- /.col-8 data-wrap -->
        <div class="col-4">
            <h4>Данные корзины</h4>
            <?php
            require_once 'cart.php';
            $cart = new Cart();
            $price = 0;
            foreach($cart->cart as $id => $count){
                $stmt = $pdo->query("SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id WHERE id_prod='$id'");

                while ($row = $stmt->fetch()){
                    echo'

            <div class="list-product">
                        <h4 class="product-title">'.$row['name'].'</h4>
                        <p>Количество: '.$count.'</p>
                        <p><b>'.$row['price'].' руб.</b></p>         
            </div> ';
                    $price+= $row['price']*$count;
                }

            }

            ?>
            <div class="list-product">
                <p><b>Итого: <?= $price; ?> руб.</b></p>
            </div>


        </div>
    </div>
</div>
