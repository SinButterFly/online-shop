<?php
require_once 'db.php';
require_once 'cart.php';

$cart = new Cart();
foreach($cart->cart as $id => $count) {
    $stmt = $pdo->query("SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id WHERE id_prod='$id'");
}


require_once 'header.php';
?>

<div class="container">
    <h2>Оформление заказа</h2>
    <div class="row">
        <div class="col-8 data-wrap">
            <div class="user-form">

                <form action="">
                    <h4>Данные пользователя</h4>
                    <div class="form-group">

                        <input class="form-control" name="name_customer" type="text" placeholder="Имя">
                        <input class="form-control" name="email_customer" type="email" placeholder="Email">
                        <input class="form-control" name="tel_customer" type="text" placeholder="Телефон">

                    </div>

                </form>
            </div>
        </div>
        <!-- /.col-8 data-wrap -->
        <div class="col-4">
            <h4>Данные корзины</h4>
            <?php
            require_once 'cart.php';
            $cart = new Cart();
            $price = 0;
            foreach($cart->cart as $id => $count){
                $stmt = $pdo->query("SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id WHERE id_prod='$id'");

                while ($row = $stmt->fetch()){
                    echo'

            <div class="list-product">
                        <h4 class="product-title">'.$row['name'].'</h4>
                        <p>Количество: '.$count.'</p>
                        <p><b>'.$row['price'].' руб.</b></p>         
            </div> ';
                    $price+= $row['price']*$count;
                }

            }

            ?>
            <div class="list-product">
                <p><b>Итого: <?= $price; ?> руб.</b></p>
            </div>
            <a href="#" class="btn btn-warning">Оформить заказ</a>

        </div>
    </div>
</div>
