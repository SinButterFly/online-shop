<?php
session_start();
require 'db.php';


?>
<!doctype html>
<html lang="en">
  <head>
    <title>Интернет-магазин</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/css/bootstrap.min.css" integrity="sha384-PsH8R72JQ3SOdhVi3uxftmaW6Vc51MKb0q5P2rRUpPvrszuE4W1povHYgTpBfshb" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="/">Главная</a>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <?php

      $pro = $pdo->query('SELECT `user_name`,`role` FROM `users` WHERE `user_name`="'.$_SESSION['auth'].'"');
      $proverka = $pro->fetch();

      if($proverka['role'] == 2){
          echo '
        <ul class="navbar-nav mr-auto">
        <li class="nav-item">
            <a class="nav-link" href="create.php">Создать продукт</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="create_cat.php">Создать категорию</a>
        </li>
    </ul> ';
      }
      ?>
  </div>
        <form class="form-inline ml-1" method="POST" name="search" action="search.php">
            <input class="form-control mr-2" type="search" name="search" placeholder="Поиск" aria-label="Поиск">
            <button class="btn btn-info " type="submit">Найти</button>
        </form>



        <?php
        if(isset($_SESSION['auth'])){

            echo '
                <ul class="navbar-nav mr-auto ">
                <li class="nav-item">
                    <a href="exit.php"><input class="btn btn-info ml-1 " type="button" value="Выход"></a>
                </li>
            </ul>
            ';
            }

            else {
                echo'
            <ul class="navbar-nav mr-auto ">
                <li class="nav-item">
                    <a href="auth.php"><input class="btn btn-info ml-1 " type="button" value="Авторизация"></a>
                </li>
                <li class="nav-item ml-1">
                    <a href="reg.php"><input class="btn btn-info" type="button" value="Регистрация"></a>
    
                </li>
            </ul>
            ';
        }
        ?>

</nav>