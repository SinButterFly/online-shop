<?php
require_once 'db.php';
require_once 'phpmailer/PHPMailer.php';
require_once 'phpmailer/SMTP.php';
require_once 'cart.php';



$title = "Заявка Online-Shop";

$name_customer = $_POST['name_customer'];
$email_customer = $_POST['email_customer'];
$tel_customer = $_POST['tel_customer'];
$delivery = $_POST['delivery'];

$cart = new Cart();
$price = 0;

foreach($cart->cart as $id => $count){
    $stmt = $pdo->query("SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id WHERE id_prod='$id'");

    while ($row = $stmt->fetch()){
        $price+= $row['price']*$count;
    }

}

$body = "
<h2>Заявка</h2>
<b>Имя:</b> $name_customer<br>
<b>Почта:</b> $email_customer<br><br>
<b>Номер телефона:</b> $tel_customer<br>
<b>Сумма заказа:</b> $price<br>
<b>Способ доставки:</b> $delivery
";
$mail = new PHPMailer\PHPMailer\PHPMailer();

try {
    $mail->isSMTP();
    $mail->CharSet = "UTF-8";
    $mail->SMTPAuth = true;
    $mail->SMTPDebug = 2;

    $mail->Debugoutput = function ($str, $level) {
        $GLOBALS['status'][] = $str;
    };

    $mail->Host = 'smtp.mail.ru'; // SMTP сервера почты
    $mail->Username = 'sinssni-web@mail.ru'; // Логин почты
    $mail->Password = 'khpk_123$'; // Пароль от почты
    $mail->SMTPSecure = 'ssl';
    $mail->Port = 465;
    $mail->setFrom('sinssni-web@mail.ru', 'sinssni-web@mail.ru'); //отправитель mail/login

// Получатель письма
    $mail->addAddress('sinssni-web@mail.ru');

// Отправка сообщения
    $mail->isHTML(true);
    $mail->Subject = $title;
    $mail->Body = $body;

// Проверяка отравки сообщения
    if ($mail->send()) {
        $result = "success";
    } else {
        $result = "error";
    }

} catch (Exception $e) {
    $result = "error";
    $status = "Сообщение не было отправлено. Причина ошибки: {$mail->ErrorInfo}";
}

