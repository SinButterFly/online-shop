<?php
session_start();
require 'db.php';
require_once 'check_admin.php';

$message = '';
if (isset ($_POST['name'])) {
    $name = $_POST['name'];
    $desc_p = $_POST['desc_p'];
    $price = $_POST['price'];
    $photo = $_FILES['photo'];
    $cat_id = $_POST['cat_id'];

    $photoName = $_FILES['photo']['name'];
    $photoTmpName = $_FILES['photo']['tmp_name'];
    $photoSize = $_FILES['photo']['size'];
    $photoError = $_FILES['photo']['error'];
    $photoType = $_FILES['photo']['type'];

    $photoExt = explode('.', $photoName);
    $photoActualExt = strtolower(end($photoExt));

    $allowed = array('jpg' , 'jpeg', 'png');

    if (in_array($photoActualExt, $allowed)){
        if ($photoError === 0){
            if ($photoSize < 1000000){
                $photoNameNew = uniqid('', true).".".$photoActualExt;
                $photoDestination = 'img/'.$photoNameNew;
                move_uploaded_file($photoTmpName, $photoDestination);

            }else echo "Файл слишком большой";
        }else{
            echo "Ошибка при загрузке";
        }
    } else{
        echo "Ошибка";
    }




  $sql = "INSERT INTO products (name, desc_p, price, cat_id, photo)
          VALUES('$name', '$desc_p', '$price', '$cat_id', '$photoDestination')";
  $stmt = $pdo->prepare($sql);
  if ($stmt->execute([$name => $name, $desc_p => $desc_p, $price => $price, $cat_id => $cat_id])) {
    $message = 'Продукт добавлен';
  }

}
require 'header.php';

?>

<div class="container">
  <div class="card mt-5">
    <div class="card-header">
      <h2>Добавить продукт</h2>
    </div>
    <div class="card-body">
      <?php if(!empty($message)): ?>
        <div class="alert alert-success">
          <?= $message; ?>
        </div>
      <?php endif; ?>
      <form method="post" enctype="multipart/form-data">
        <div class="form-group">
          <label for="name">Имя</label>
          <input type="text" name="name" id="name" class="form-control">
        </div>
        <div class="form-group">
          <label for="desc_p">Описание</label>
          <input type="text" name="desc_p" id="desc_p" class="form-control">
        </div>
          <div class="form-group">
              <label for="price">Цена</label>
              <input type="text" name="price" id="price" class="form-control">
          </div>
          <div class="form-group">
              <label for="photo">Фотография</label>
              <input type="file" name="photo" id="photo" class="form-control">
          </div>
          <div class="form-group">
              <select name="cat_id"  title="Категории">
                  <?php
                  require_once 'db.php';
                  $stmt = $pdo->query("SELECT * FROM `categories`");
                  while ($row = $stmt->fetch()){
                      echo '<option value="' . $row['id_cat'] . '">' . $row['name_cat'] . '</option>';
                  }
                  ?>
              </select>
          </div>
        <div class="form-group">
          <button type="submit" class="btn btn-info">Добавить продукт</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php require 'footer.php'; ?>
