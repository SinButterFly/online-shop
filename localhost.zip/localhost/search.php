<?php
require 'db.php';
require 'header.php';

$search=$_POST['search'];

$sql = "SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id  WHERE `name` LIKE '%$search%'";
$stmt = $pdo->query($sql);
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_OBJ);

?>

<div class="row">
<?php foreach($products as $product): ?>

    <div class="card" style="width: 33%">

        <div class="img_wrap">
            <img src="<?= $product->photo; ?>" alt="<?= $product->photo; ?>"style="width: 12rem; margin:auto;">
        </div>

        <div class="card-body">
            <h5 class="card-title"><?= $product->name; ?></h5>
            <p class="card-text">Оптсание: <?= $product->desc_p; ?></p>
            <p class="card-text">Цена: <?= $product->price; ?></p>
            <p class="card-text">Категория: <?= $product->name_cat; ?></p>
        </div>
    </div>
<?php endforeach; ?>
</div>

