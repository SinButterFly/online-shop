<?php
session_start();
require 'db.php';

$pro = $pdo->query('SELECT `user_name`,`role` FROM `users` WHERE `user_name`="'.$_SESSION['auth'].'"');
$proverka = $pro->fetch();

if($proverka['role'] !=2){
    header('location: index.php');
}
$id = $_GET['id'];
$sql = 'DELETE FROM products WHERE id_prod='.$id;
$stmt = $pdo->prepare($sql);
if ($stmt->execute([$id => $id])) {
  header("Location: /");
}