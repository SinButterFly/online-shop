<?php
session_start();

require_once 'db.php';

if(isset($_SESSION['auth'])){

    $pro = $pdo->query('SELECT `user_name`,`role` FROM `users` WHERE `user_name`="'.$_SESSION['auth'].'"');
    $proverka = $pro->fetch();
    if($proverka['role'] != 2){
        header('location: index.php');
    } else {
        header('location: admin_panel.php');
    }
} else{
    echo 'Привет гость';
}

