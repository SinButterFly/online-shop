<?php
session_start();
require 'db.php';


if(isset($_SESSION['auth'])){
    if($_POST['role']==2){
        echo 'Привет админ';
    } else {
        echo 'Привет пользователь';
    }
} else{
    echo 'Привет гость';
}