<?php
require 'header.php';

require_once 'db.php';

;


?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<div class="container">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">First</th>
        <th scope="col">Last</th>
        <th scope="col">Handle</th>
    </tr>
    </thead>
<?php
require_once 'cart.php';
$cart = new Cart();
foreach($cart->cart as $id => $count){
 $stmt = $pdo->query("SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id WHERE id_prod='$id'");
        while ($row = $stmt->fetch()){
            echo'
                <td><h5 class="card-title">'.$row['name'].'</h5></td>
                <td><a href="remove_cart.php?id='.$row['id_prod'].'">-</a>
                <a>'.$count.'</a>
                <a href="add_cart.php?id='.$row['id_prod'].'">+</a></td>
                <td><a href="delete_cart.php?id='.$row['id_prod'].'" class="btn btn-info">Удалить </a> </td>
            ';
        }
}
?>

    <?php require 'footer.php'; ?>
</div>

<!---->
<!--    <div class="row">-->
<!---->
<!--        <div class="col-3 img_wrap">-->
<!--            <img src="--><?//= $product->photo; ?><!--" alt="--><?//= $product->photo; ?><!--"style="width: 100%; margin:auto;">-->
<!--        </div>-->
<!---->
<!--        <div class="col-9 justify-content-reverse">-->
<!--            <h5 class="card-title">--><?//= $product->name; ?><!--</h5>-->
<!--            <p class="card-text">Цена: --><?//= $product->price; ?><!--</p>-->
<!--            <p class="card-text">Категория: --><?//= $product->name_cat; ?><!--</p>-->
<!---->
<!--            <a href='add_cart.php?id=--><?//= $product->id_prod?><!--' class='btn btn-info'>-</a>-->
<!--            <p></p>-->
<!--            <a href='remove_cart.php?id=--><?//= $product->id_prod?><!--' class='btn btn-info'>+</a>-->
<!---->
<!--        </div>-->
<!---->
<!--    </div>-->
<!--    ?>-->
<!---->
<!--</div>-->