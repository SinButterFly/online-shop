<?php
$dsn = 'mysql:host=localhost;dbname=catalog';
$username = 'root';
$password = 'root';
$options = [];
try {
$pdo = new PDO($dsn, $username, $password, $options);
} catch(PDOException $e) {
}