<?php
session_start();
require 'db.php';

$log = $_POST['user_name'];
$password = $_POST['password'];

$stmt = $pdo->query('SELECT `user_name`, `role`, `password` FROM `users` WHERE `user_name`="'.$log.'"');

$result = $stmt->fetch();

if(md5($password) == $result['password']) {
    $_SESSION['auth'] = $result['login'];
    header('location:check.php');
}else{
    echo 'Ты не прошёл';
}
