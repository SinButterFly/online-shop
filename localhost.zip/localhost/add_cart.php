<?php

require_once 'cart.php';

$cart = new Cart();

$cart->addProduct($_GET['id']);
