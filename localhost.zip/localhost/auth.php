<?php 
session_start();
require 'header.php';

?>

<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Авторизация</title>
</head>


<body>

    <div class="form-wrap">
        <h2 class="form-header">Авторизация</h2>
        <form action="log.php" method="post">
            <div class="form-group">
                <input class="form-control" type="text" name="role" hidden>
                <input class="form-control" type="text" name="user_name" placeholder="Логин" required>
                <input class="form-control" type="password" name="password" placeholder="Пароль" required>
                <input class="btn btn-info" type="submit" value="Войти" name="auth">
            </div>
         </form>
    </div>


</body>


</html>