<?php 
session_start();
require 'db.php';
$email = $_POST['email'];
$password = $_POST['password'];

$stmt = $pdo->query('SELECT user_name, email, password FROM `users` WHERE email="'.$email.'"');

$result = $stmt->fetch();


if ($_POST['auth'])
    {
    if(md5($password) == $result['password']){
        $user_name = $result['user_name'];
        $_SESSION['user_name'] = $user_name;
        header("Location: close_page.php");


    }else echo 'Такого пользователя не существует';
}

require 'header.php';

?>

<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Авторизация</title>
</head>


<body>

    <div class="form-wrap">
        <h2 class="form-header">Авторизация</h2>
        <form action="auth.php" method="post">
            <div class="form-group">
                <input class="form-control" type="email" name="email" placeholder="Почта" required>
                <input class="form-control" type="password" name="password" placeholder="Пароль" required>
                <input class="btn btn-info" type="submit" value="Войти" name="auth">
            </div>
         </form>
    </div>


</body>


</html>