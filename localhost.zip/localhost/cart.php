<?php

echo '<pre>';

$cart_json = $_COOKIE['cart'];
$cart = json_decode($_COOKIE['cart'], true);

var_dump($cart_json);
var_dump($cart);