<?php

class Cart{
    public $cart;

    public function __construct(){
        $this->getCart();
    }

    private function getCart(){
        if(!isset($_COOKIE["cart"])){
            setcookie("cart", "{}", time() + 60*60*60);
        }
        $this->cart = json_decode($_COOKIE['cart'], true);
    }

    private function saveCart($cart = null){
        setcookie('cart', json_encode($cart ?? $this->cart), time() + 60*60*60);
    }

    public function  addProduct($id, $count=1){
        $this->cart[$id] = ($this->cart[$id] ?? 0) + $count;
        $this->saveCart();
    }


}

