<?php
session_start();
require 'db.php';
require 'header.php';

$pro = $pdo->query('SELECT `user_name`,`role` FROM `users` WHERE `user_name`="'.$_SESSION['auth'].'"');
$proverka = $pro->fetch();

if($proverka['role'] !=2){
    header('location: index.php');
}

