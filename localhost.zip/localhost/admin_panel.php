<?php
session_start();
require 'db.php';
require_once 'check_admin.php';


require 'header.php';