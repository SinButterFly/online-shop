<?php
session_start();
require 'db.php';
require_once 'check_admin.php';


require 'header.php';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<?php

if (!empty($_POST["filter"])) {
    $sql = "SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id";
    $ids = $_POST["categories"];
    if ($ids == NULL){
        $sql = "SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id";
        $stmt = $pdo->prepare($sql);
    }else{
        $inQuery = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare($sql. ' WHERE products.cat_id IN(' . $inQuery . ')');
    }
}else{
    $sql = "SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id";
    $stmt = $pdo->prepare($sql);
}
$stmt->execute($ids);
$products = $stmt->fetchAll(PDO::FETCH_OBJ);

?>
<table class="table">
    <thead>
    <tr>
        <th scope="col">id</th>
        <th scope="col">Наименование</th>
        <th scope="col">Описание</th>
        <th scope="col">Цена</th>
        <th scope="col">Категория</th>
        <th scope="col">Удалить</th>
        <th scope="col">Редактировать</th>
    </tr>
    </thead>
<?php foreach($products as $product): ?>




<tbody>
        <div class="table">
            <h5 ><?= $product->name; ?></h5>
            <p >Цена: <?= $product->price; ?></p>
            <p >Категория: <?= $product->name_cat; ?></p>
            <a href='shopcart.php?id=<?= $product->id_prod?>' class='btn btn-info'>Добавить в корзину</a>
        </div>
    </div>

</tbody>
<?php endforeach; ?>
</body>
</html>
