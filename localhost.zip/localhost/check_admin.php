<?php

$check = $pdo->query('SELECT `user_name`,`role` FROM `users` WHERE `user_name`="'.$_SESSION['auth'].'"');
$result = $check->fetch();

if($result['role'] !=2){
    header('location: index.php');
}
