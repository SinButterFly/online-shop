<?php

require 'db.php';
 ?>
<?php require 'header.php'; ?>
<div class="container">
  <div class="mt-5">
    <div class="header">
      <h2>Продукты</h2>


        Фильтр: перевести на checkbox
        <form action="" method="post">
                <?php
                require_once 'db.php';
                $stmt = $pdo->query("SELECT * FROM categories");
                echo '<input type="checkbox" id="all" name="Все товары" checked>';
                while ($row = $stmt->fetch()){
                    echo '<option value="' . $row['id_cat'] . '">' . $row['name_cat'] . '</option>';
                    echo '<input type="checkbox" id="' . $row['id_cat'] . '" name="' . $row['name_cat'] . '" checked>';
                }
                ?>
            <input type="submit" name="filter">
        </form>


    </div>
    <div class="row">
        <?php
            $sql = "SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id";
            if(isset($_POST['filter']) && (trim($_POST['cat_id'])!='') && (trim($_POST['cat_id'])!='all')) {
                //add the condition
                $sql.= " WHERE id_cat='".trim($_POST['cat_id'])."'";
            }
        $stmt = $pdo->prepare($sql);
        $stmt->execute();
        $products = $stmt->fetchAll(PDO::FETCH_OBJ);
        ?>
      <?php foreach($products as $product): ?>
          
          <div class="card" style="width: 25%">

            <div class="img_wrap">
              <img src="<?= $product->photo; ?>" alt="<?= $product->photo; ?>"style="width: 12rem; margin:auto;">
            </div>

            <div class="card-body">
              <h5 class="card-title"><?= $product->name; ?></h5>
<!--              <p class="card-text">--><?//= $product->desc_p; ?><!--</p>-->
              <p class="card-text">Цена: <?= $product->price; ?></p>
              <p class="card-text">Категория: <?= $product->name_cat; ?></p>
              <a href="edit.php?id=<?= $product->id_prod ?>" class="btn btn-info">Редактировать</a>
              <a onclick="return confirm('Действительно хотите удалить?')" href="delete.php?id=<?= $product->id_prod ?>" class='btn btn-danger'>Удалить</a>
            </div>
          </div>
      <?php endforeach; ?>
      </div>
  </div>
</div>
<?php require 'footer.php'; ?>