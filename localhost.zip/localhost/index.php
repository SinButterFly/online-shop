<?php

require 'db.php';
$sql = 'SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id';
$stmt = $pdo->prepare($sql);
$stmt->execute();
$products = $stmt->fetchAll(PDO::FETCH_OBJ);
 ?>
<?php require 'header.php'; ?>
<div class="container">
  <div class="mt-5">
    <div class="header">
      <h2>Продукты</h2>
    </div>
      <?php foreach($products as $product): ?>
          <div class="row">
              <? header("Content-Type: image/jpeg"); ?>
              <div class="photo-product col-5"><img src="<?= $product->photo; ?>" alt="<?= $product->photo; ?>"></div>

              <div class="info col-7">
                  <div id="name"><?= $product->name; ?></div>
                  <div id="desc_p"><?= $product->desc_p; ?></div>
                  <div id="desc_p"><?= $product->price; ?></div>
                  <div id="desc_p"><?= $product->name_cat; ?></div>

                  <a href="edit.php?id=<?= $product->id_prod ?>" class="btn btn-info">Редактировать</a>
                  <a onclick="return confirm('Действительно хотите удалить?')" href="delete.php?id=<?= $product->id_prod ?>" class='btn btn-danger'>Удалить</a>
              </div>
          </div>
      <?php endforeach; ?>
  </div>
</div>
<?php require 'footer.php'; ?>

//фильтрация по категории
