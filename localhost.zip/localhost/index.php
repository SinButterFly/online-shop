<?php

require 'db.php';
require 'header.php';




?>

<div class="container">
  <div class="mt-5">
    <div class="header">

      <h2>Продукты</h2>


        Фильтр:
        <form action="" method="post" >
                <?php
                require_once 'db.php';
                $stmt = $pdo->query("SELECT * FROM categories");
                while ($row = $stmt->fetch()){
                    echo "<input type='checkbox' value='".$row['id_cat']."' name='categories[]'>";
                    echo "<label for='categories''> ".$row['name_cat']."</label>";
                    echo "<br>";
                }
                ?>
            <input type="submit" class="btn btn-info" name="filter" value="Применить">

        </form>


    </div>
    <div class="row">
        <?php

        if (!empty($_POST["filter"])) {
            $sql = "SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id";
            $ids = $_POST["categories"];
            if ($ids == NULL){
                $sql = "SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id";
                $stmt = $pdo->prepare($sql);
            }else{
                $inQuery = implode(',', array_fill(0, count($ids), '?'));
                $stmt = $pdo->prepare($sql. ' WHERE products.cat_id IN(' . $inQuery . ')');
            }
        }else{
            $sql = "SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id";
            $stmt = $pdo->prepare($sql);
        }
            $stmt->execute($ids);
            $products = $stmt->fetchAll(PDO::FETCH_OBJ);

        ?>
      <?php foreach($products as $product): ?>

          <div class="card" style="width: 25%">

            <div class="img_wrap">
              <img src="<?= $product->photo; ?>" alt="<?= $product->photo; ?>"style="width: 12rem; margin:auto;">
            </div>

            <div class="card-body">
              <h5 class="card-title"><?= $product->name; ?></h5>
<!--              <p class="card-text">--><?//= $product->desc_p; ?><!--</p>-->
              <p class="card-text">Цена: <?= $product->price; ?></p>
              <p class="card-text">Категория: <?= $product->name_cat; ?></p>

          <?php
          $pro = $pdo->query('SELECT `user_name`,`role` FROM `users` WHERE `user_name`="' . $_SESSION['auth'] . '"');
          $proverka = $pro->fetch();

          if ($proverka['role'] == 2) {
              echo '
              <a href="edit.php?id=<?= $product->id_prod ?>" class="btn btn-info">Редактировать</a>
              <a onclick="return confirm("Действительно хотите удалить?")" href="delete.php?id=<?= $product->id_prod ?>" class="btn btn-danger">Удалить</a>';
          }
          ?>

            </div>
          </div>
      <?php endforeach; ?>
      </div>
  </div>
</div>
<?php require 'footer.php'; ?>