<?php
require 'db.php';
require 'header.php';


?>

<div class="container">
    <h2 class="m-4">Продукты</h2>
<div class="row">
    <!-- фильтр сбоку col-3 -->
        <div class="col-md-3">
            <p>Фильтр:</p>
            <form method="post" >
                <?php
                require_once 'db.php';
                $stmt = $pdo->query("SELECT * FROM categories");
                while ($row = $stmt->fetch()){
                    echo "<input type='checkbox' value='".$row['id_cat']."' name='categories[]'>";
                    echo "<label for='categories''> ".$row['name_cat']."</label>";
                    echo "<br>";
                }
                ?>
                <input type="submit" class="btn btn-info" name="filter" value="Применить">

            </form>
        </div>

    <!-- каталог col-9 -->
    <div class="col-md-9">
        <div class="row">
            <?php

            if (!empty($_POST["filter"])) {
                $sql = "SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id";
                $ids = $_POST["categories"];
                if ($ids == NULL){
                    $sql = "SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id";
                    $stmt = $pdo->prepare($sql);
                }else{
                    $inQuery = implode(',', array_fill(0, count($ids), '?'));
                    $stmt = $pdo->prepare($sql. ' WHERE products.cat_id IN(' . $inQuery . ')');
                }
            }else{
                $sql = "SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id";
                $stmt = $pdo->prepare($sql);
            }
                $stmt->execute($ids);
                $products = $stmt->fetchAll(PDO::FETCH_OBJ);

            ?>
          <?php foreach($products as $product): ?>

          <div class="card" style="width: 33%">

            <div class="img_wrap">
              <img src="<?= $product->photo; ?>" alt="<?= $product->photo; ?>"style="width: 12rem; margin:auto;">
            </div>

            <div class="card-body">
              <h5 class="card-title"><?= $product->name; ?></h5>
              <p class="card-text">Цена: <?= $product->price; ?></p>
              <p class="card-text">Категория: <?= $product->name_cat; ?></p>
                <a href='shopcart.php?id=<?= $product->id_prod?>' class='btn btn-info'>Добавить в корзину</a>
            </div>
          </div>


          <?php endforeach; ?>

        </div>
    </div>
</div>
</div>

<?php require 'footer.php'; ?>

