<?php
require_once 'cart.php';

$cart = new Cart();

$cart->removeProduct($_GET['id']);

header('Location:'.$_SERVER['HTTP_REFERER']);