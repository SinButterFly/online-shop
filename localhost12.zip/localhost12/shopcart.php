<?php
session_start();
require 'header.php';

require_once 'db.php';

;


?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<div class="container">
    <h2>Корзина</h2>

<?php
require_once 'cart.php';
$cart = new Cart();
foreach($cart->cart as $id => $count){
 $stmt = $pdo->query("SELECT * FROM products JOIN `categories` ON categories.id_cat = products.cat_id WHERE id_prod='$id'");
        while ($row = $stmt->fetch()){
            echo'

            <div class="row cart-product">
                <div class="wrap-image col-3">
                   <img src="'.$row['photo'].'" alt="картинка"style="width: 50%; margin:auto;"> 
                </div>
                <div class="wrap-content row col-9 ">
                    <div class="col-4">
                        <h4 class="product-title">'.$row['name'].'</h4>
                        <p>Цена: '.$row['price'].'</p>
                        <p>Категория: '.$row['name_cat'].'</p>
                    </div>
              
                    <div class="row add_remove_prod col-4">
                        <div class="border-prod">
                        <a href="remove_cart.php?id='.$row['id_prod'].'">-</a>
                        <a>'.$count.'</a>
                        <a href="add_cart.php?id='.$row['id_prod'].'">+</a>
                        </div>
                    </div>
                   <div class="col-4">
                        <a href="delete_cart.php?id='.$row['id_prod'].'" class="btn btn-info button-delete">Удалить </a>
                    </div>
                </div>
                
            </div>
             
                
                
            ';
        }
}
?>

    <a href="page_order.php" class="btn btn-info button-fixed">Оформить заказ</a>

    <?php require 'footer.php'; ?>
</div>